**To disassociate a domain name from a service**

The following ``disassociate-custom-domain`` example disassociates the domain ``example.com`` from an App Runner service.
The call also disassociates the subdomain ``www.example.com`` that was associated together with the root domain. ::

    aws apprunner disassociate-custom-domain \
        --cli-input-json file://input.json

Contents of ``input.json``::

    {
        "ServiceArn": "arn:aws:apprunner:us-west-2:123456789012:service/python-app/8fe1e10304f84fd2b0df550fe98a71fa",
        "DomainName": "example.com"
    }

Output::

    {
        "CustomDomain": {
            "CertificateValidationRecords": [
                {
                    "Name": "_70d3f50a94f7c72dc28784cf55db2f6b.example.com",
                    "Status": "PENDING_VALIDATION",
                    "Type": "CNAME",
                    "Value": "_1270c137383c6307b6832db02504c4b0.bsgbmzkfwj.acm-validations.aws."
                },
                {
                    "Name": "_287870d3f50a94f7c72dc4cf55db2f6b.www.example.com",
                    "Status": "PENDING_VALIDATION",
                    "Type": "CNAME",
                    "Value": "_832db01270c137383c6307b62504c4b0.mzkbsgbfwj.acm-validations.aws."
                }
            ],
            "DomainName": "example.com",
            "EnableWWWSubdomain": true,
            "Status": "DELETING"
        },
        "DNSTarget": "psbqam834h.us-west-2.awsapprunner.com",
        "ServiceArn": "arn:aws:apprunner:us-west-2:123456789012:service/python-app/8fe1e10304f84fd2b0df550fe98a71fa"
    }

For more information, see `Managing custom domain names for an App Runner service <https://docs.aws.amazon.com/apprunner/latest/dg/manage-custom-domains.html>`__ in the *AWS App Runner Developer Guide*.
